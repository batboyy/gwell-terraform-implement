import git
import os

git.Git("C:/Users/Dell/Pictures").clone("https://github.com/batboyy/CI-CD-version.git")
